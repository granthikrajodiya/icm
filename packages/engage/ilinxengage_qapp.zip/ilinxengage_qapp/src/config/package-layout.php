<?php

return [
    'engage_ilinxengage_qapp' => [
        'configuration' => [
            'title' => 'Sample configuration',
            'description' => 'Configuration for sample',
            'tab_id' => 'tabs-qapp-configuration',
            'template' => 'index',
        ]
    ]
];
